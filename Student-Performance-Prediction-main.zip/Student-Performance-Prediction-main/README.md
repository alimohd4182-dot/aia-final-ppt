# Student Performance Prediction Using Machine Learning
### AIA College Project | Python | Supervised Learning | Regression

## 1. Project overview
This project estimates a student's final Mathematics grade (`G3`, on a 0–20 scale) using demographic, family, school, study-habit and lifestyle attributes from the UCI Student Performance Mathematics dataset.

**Important modelling decision:** `G1` and `G2` (earlier-period grades) are excluded from the predictors. They are strongly associated with `G3`; using them would make the task easier but would leak near-direct prior academic performance into the prediction. This project instead studies prediction from non-grade attributes.

## 2. Dataset
- Name: Student Performance (Mathematics)
- Source: UCI Machine Learning Repository
- Official page: https://archive.ics.uci.edu/dataset/320/student-performance
- Original authors: Paulo Cortez and Alice Silva
- Mathematics subset: 395 observations, 33 columns (including target)
- File: `data/student-mat.csv`
- Separator: semicolon (`;`)
- Target: `G3`

The code automatically downloads the official UCI archive on first run. If automatic download is unavailable, download the Mathematics CSV from the official UCI page and place it at `data/student-mat.csv`.

## 3. Algorithms compared
- Dummy Regressor (mean baseline)
- Linear Regression
- Ridge Regression
- Random Forest Regressor
- Extra Trees Regressor
- HistGradientBoosting Regressor

The best model is selected by the lowest held-out test MAE. Random Forest is a strong candidate for tabular nonlinear data, but the project does not assume it wins: the actual evaluation determines the selected model.

## 4. Preprocessing
- Check missing values and exact duplicate rows.
- Remove exact duplicate records.
- Numeric features: median imputation and standardisation.
- Categorical features: most-frequent imputation and one-hot encoding.
- Preprocessing is fitted inside an sklearn Pipeline, using training data only, to avoid data leakage.
- Correlation heatmap is generated for numeric columns.
- `G1`, `G2`, and target `G3` are excluded from input features.

## 5. Train/test split and metrics
- 80% training / 20% testing
- Fixed `random_state=42` for reproducibility
- Five-fold cross-validation on training data
- Metrics: MAE, RMSE and R²; CV MAE mean and standard deviation

MAE and RMSE are measured in grade points. R² may be negative on a test set and should be interpreted in context. Lower MAE/RMSE is better; higher R² is generally better.

## 6. Setup and execution
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python main.py
```

The first run downloads the UCI dataset if it is not already in `data/`.

## 7. Generated files
After running `python main.py`:
- `outputs/model_comparison.csv`
- `outputs/evaluation_summary.json`
- `outputs/data_quality_report.json`
- `outputs/test_predictions.csv`
- `outputs/correlation_heatmap.png`
- `outputs/model_comparison.png`
- `outputs/actual_vs_predicted.png`
- `models/best_model.joblib`

## 8. GitHub submission
1. Create a new public repository named `student-performance-prediction-aia`.
2. Upload this project folder (including source, README, requirements and generated outputs).
3. Do not upload `.venv/`, cache folders or private credentials.
4. Add the UCI citation below to the repository description or README.
5. Include the actual generated model results after running the project.

## 9. Limitations and responsible use
- The dataset is small and comes from two secondary schools in Portugal (2005–2006); results may not generalise to other countries, schools or current students.
- Predictions are estimates, not official grades or judgments of a student's ability.
- Correlation does not establish causation.
- Features such as family background and demographics can encode social inequalities. The model should be used only for learning and should not be used to make consequential decisions about students.
- A random holdout split is not an external validation study.

## 10. Dataset citation
Cortez, P. (2008). *Student Performance* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5TG7T

Cortez, P., & Silva, A. (2008). Using data mining to predict secondary school student performance. Proceedings of the 5th Annual Future Business Technology Conference.

Dataset license and terms are described on the official UCI page. Cite the original source when reusing the data.
