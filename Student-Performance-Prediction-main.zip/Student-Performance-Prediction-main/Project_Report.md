# AIA Project Report
## Student Performance Prediction Using Machine Learning

### Abstract
This project develops a supervised machine-learning regression workflow to estimate the final Mathematics grade of secondary-school students. It uses the UCI Student Performance Mathematics dataset and compares baseline and ensemble regression algorithms. Data cleaning, categorical encoding, numerical imputation, correlation analysis, train/test splitting, model training and evaluation are performed through a reproducible Python pipeline.

### 1. Introduction
Student academic outcomes are influenced by a combination of school, family, study and lifestyle factors. Data analysis can help explore relationships among these variables and build an educational prediction model. The objective here is to estimate the final Mathematics grade (`G3`) from non-grade attributes.

### 2. Problem statement
Given a student's non-grade attributes, estimate their final Mathematics grade on the dataset's 0–20 scale. This is a regression problem because the target is numeric.

### 3. Objectives
1. Study and understand a real-world educational dataset.
2. Identify missing values and duplicate records.
3. Encode categorical attributes and prepare numerical attributes.
4. Analyse correlations among numeric variables.
5. Split the data into training and testing subsets.
6. Train and compare multiple regression models.
7. Evaluate model performance with appropriate metrics.
8. Save the best fitted pipeline and document the workflow.

### 4. Dataset description
The Mathematics subset contains 395 student records and 33 original columns. The attributes cover school and demographic information, family background, study time, support, activities, absences and three period grades. `G3` is the final Mathematics grade and is the prediction target.

### 5. Methodology
**Data loading:** The CSV is read using a semicolon separator.

**Data cleaning:** The program checks missing values and removes exact duplicate rows. Missing numeric values are imputed using the training-set median; categorical values are imputed using the training-set most frequent value.

**Encoding:** Categorical variables are transformed using one-hot encoding. Numeric variables are standardised.

**Leakage prevention:** `G1` and `G2` are omitted from model inputs because they are earlier grades strongly related to `G3`. This creates a more useful, though harder, prediction task based on non-grade attributes.

**Data splitting:** 80% of records are used for training and 20% for testing with a fixed random seed.

**Model training:** Dummy, Linear Regression, Ridge, Random Forest, Extra Trees and HistGradientBoosting regressors are compared. The preprocessing steps are included in a pipeline and are fitted only on training data.

### 6. Evaluation metrics
- **MAE:** average absolute prediction error, in grade points.
- **RMSE:** square root of mean squared error; penalises larger errors more strongly.
- **R²:** proportion of target variance explained relative to a mean baseline; may be negative on unseen data.
- **Cross-validation MAE:** mean and standard deviation of five-fold training-set validation errors.

The final model is selected using the lowest test-set MAE. Actual numerical values must be copied from `outputs/model_comparison.csv` after executing the program; no results are pre-filled or fabricated.

### 7. Results
Insert the generated model comparison table here from `outputs/model_comparison.csv`.

Insert the following generated figures:
- `outputs/correlation_heatmap.png`
- `outputs/model_comparison.png`
- `outputs/actual_vs_predicted.png`

### 8. Conclusion
The project demonstrates an end-to-end supervised learning workflow for an educational regression task. It compares several algorithms using a held-out test set and cross-validation, and saves the selected preprocessing-and-model pipeline. The conclusion about which model performs best must be based on the measured results produced by the program.

### 9. Future scope
- Validate on a larger and more recent dataset.
- Evaluate generalisation across schools using group-based or external validation where suitable identifiers are available.
- Investigate feature importance and explainability carefully.
- Conduct fairness analysis before any real-world use.
- Develop a secure dashboard for educational demonstration.

### 10. Limitations and ethics
The dataset is small, historical and drawn from two Portuguese schools. Its patterns may not generalise to other educational settings. Predictions are estimates and must not be used as official grades or as the sole basis for decisions about students. Associations in the dataset do not prove causation.

### References
1. Cortez, P. (2008). *Student Performance* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5TG7T
2. Cortez, P., & Silva, A. M. G. (2008). Using data mining to predict secondary school student performance. Proceedings of the 5th Annual Future Business Technology Conference.
