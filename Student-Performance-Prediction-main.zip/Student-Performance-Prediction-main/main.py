"""
AIA Project: Student Performance Prediction using Machine Learning
Run: python main.py
Dataset: UCI Student Performance - Mathematics (student-mat.csv)
"""
from pathlib import Path
import json, urllib.request, zipfile, io, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, HistGradientBoostingRegressor
import joblib

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent
DATA_DIR, OUT_DIR, MODEL_DIR = ROOT/"data", ROOT/"outputs", ROOT/"models"
for p in (DATA_DIR, OUT_DIR, MODEL_DIR): p.mkdir(exist_ok=True)
CSV = DATA_DIR/"student-mat.csv"
UCI_ZIP = "https://archive.ics.uci.edu/static/public/320/student+performance.zip"

def acquire_dataset():
    """Download official UCI archive only if the Mathematics CSV is not present."""
    if CSV.exists():
        return
    print("Dataset not found. Downloading the official UCI Student Performance archive...")
    try:
        request = urllib.request.Request(UCI_ZIP, headers={"User-Agent": "AIA-Student-Project/1.0"})
        with urllib.request.urlopen(request, timeout=30) as response:
            archive = zipfile.ZipFile(io.BytesIO(response.read()))
        candidate = next((n for n in archive.namelist() if n.lower().endswith("student-mat.csv")), None)
        if candidate is None:
            raise FileNotFoundError("student-mat.csv was not found inside the UCI archive.")
        CSV.write_bytes(archive.read(candidate))
        print(f"Dataset saved to {CSV}")
    except Exception as exc:
        raise RuntimeError(
            "Could not download the dataset automatically. Download student-mat.csv "
            "from https://archive.ics.uci.edu/dataset/320/student-performance and place "
            f"it inside {DATA_DIR}. Original error: {exc}"
        )

def main():
    acquire_dataset()
    # UCI files are semicolon-delimited, not comma-delimited.
    df = pd.read_csv(CSV, sep=";")
    print("\n===== DATASET OVERVIEW =====")
    print(f"Shape: {df.shape[0]} rows x {df.shape[1]} columns")
    print("\nFirst five rows:\n", df.head().to_string(index=False))
    print("\nData types:\n", df.dtypes.to_string())
    missing_before = int(df.isna().sum().sum())
    duplicates = int(df.duplicated().sum())
    df = df.drop_duplicates().copy()
    print(f"\nMissing cells: {missing_before}; exact duplicate rows removed: {duplicates}")
    print("Missing values by column:\n", df.isna().sum()[df.isna().sum() > 0].to_string())

    if "G3" not in df:
        raise ValueError("Target column G3 is missing from the dataset.")
    # G1 and G2 are deliberately excluded: they are earlier grades and create
    # target leakage for a prediction intended to use non-grade background data.
    excluded = ["G3", "G1", "G2"]
    X = df.drop(columns=excluded)
    y = pd.to_numeric(df["G3"], errors="coerce")
    valid = y.notna()
    X, y = X.loc[valid].copy(), y.loc[valid].copy()

    numeric_features = X.select_dtypes(include=["number"]).columns.tolist()
    categorical_features = X.select_dtypes(exclude=["number"]).columns.tolist()
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    preprocess = ColumnTransformer([
        ("numeric", numeric_pipe, numeric_features),
        ("categorical", categorical_pipe, categorical_features)
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    models = {
        "Dummy Baseline": DummyRegressor(strategy="mean"),
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(alpha=1.0),
        "Random Forest": RandomForestRegressor(
            n_estimators=400, min_samples_leaf=2, random_state=42, n_jobs=-1
        ),
        "Extra Trees": ExtraTreesRegressor(
            n_estimators=400, min_samples_leaf=2, random_state=42, n_jobs=-1
        ),
        "HistGradient Boosting": HistGradientBoostingRegressor(
            max_iter=150, learning_rate=0.06, l2_regularization=1.0, random_state=42
        )
    }

    rows, fitted = [], {}
    cv = KFold(n_splits=5, shuffle=True, random_state=42)
    for name, estimator in models.items():
        pipe = Pipeline([("preprocessing", preprocess), ("model", estimator)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        rmse = float(np.sqrt(mean_squared_error(y_test, pred)))
        cv_scores = cross_val_score(
            pipe, X_train, y_train, cv=cv, scoring="neg_mean_absolute_error", n_jobs=None
        )
        rows.append({
            "Model": name,
            "MAE": float(mean_absolute_error(y_test, pred)),
            "RMSE": rmse,
            "R2": float(r2_score(y_test, pred)),
            "CV_MAE_mean": float(-cv_scores.mean()),
            "CV_MAE_std": float(cv_scores.std())
        })
        fitted[name] = pipe

    results = pd.DataFrame(rows).sort_values("MAE").reset_index(drop=True)
    results.to_csv(OUT_DIR/"model_comparison.csv", index=False)
    best_name = results.iloc[0]["Model"]
    best_model = fitted[best_name]
    joblib.dump(best_model, MODEL_DIR/"best_model.joblib")
    with open(OUT_DIR/"evaluation_summary.json", "w", encoding="utf-8") as f:
        json.dump({
            "dataset_rows_after_deduplication": int(len(df)),
            "feature_count_before_encoding": int(X.shape[1]),
            "target": "G3",
            "excluded_features": excluded,
            "train_rows": int(len(X_train)),
            "test_rows": int(len(X_test)),
            "best_model_by_test_MAE": best_name,
            "metrics": results.iloc[0].to_dict(),
            "missing_cells_before_imputation": missing_before,
            "duplicate_rows_removed": duplicates
        }, f, indent=2)

    best_pred = best_model.predict(X_test)
    pred_frame = pd.DataFrame({"Actual_G3": y_test.values, "Predicted_G3": best_pred})
    pred_frame.to_csv(OUT_DIR/"test_predictions.csv", index=False)

    # Correlation analysis (numeric columns only; association is not causation).
    corr = df.select_dtypes(include=["number"]).corr(numeric_only=True)
    plt.figure(figsize=(12, 9))
    sns.heatmap(corr, cmap="coolwarm", center=0, annot=False, linewidths=.25)
    plt.title("Correlation Heatmap - Numeric Features")
    plt.tight_layout()
    plt.savefig(OUT_DIR/"correlation_heatmap.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 5))
    sns.barplot(data=results, x="MAE", y="Model")
    plt.title("Model Comparison (Lower MAE is Better)")
    plt.xlabel("Mean Absolute Error (grade points)")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig(OUT_DIR/"model_comparison.png", dpi=180)
    plt.close()

    plt.figure(figsize=(6, 6))
    plt.scatter(y_test, best_pred, alpha=.75)
    plt.plot([0, 20], [0, 20], linestyle="--")
    plt.xlim(0, 20); plt.ylim(0, 20)
    plt.xlabel("Actual final grade (G3)")
    plt.ylabel("Predicted final grade (G3)")
    plt.title(f"Actual vs Predicted - {best_name}")
    plt.tight_layout()
    plt.savefig(OUT_DIR/"actual_vs_predicted.png", dpi=180)
    plt.close()

    # Store a concise data-quality report and column lists for reproducibility.
    quality = {
        "rows_original": int(pd.read_csv(CSV, sep=";").shape[0]),
        "rows_after_duplicate_removal": int(len(df)),
        "columns": int(df.shape[1]),
        "missing_cells": missing_before,
        "duplicates_removed": duplicates,
        "numeric_features": numeric_features,
        "categorical_features": categorical_features,
        "target": "G3",
        "leakage_columns_excluded": excluded
    }
    with open(OUT_DIR/"data_quality_report.json", "w", encoding="utf-8") as f:
        json.dump(quality, f, indent=2)

    print("\n===== MODEL RESULTS (sorted by test MAE) =====")
    print(results.to_string(index=False, float_format=lambda x: f"{x:.3f}"))
    print(f"\nSelected model: {best_name}")
    print("Outputs saved in outputs/ and trained model saved in models/")
    print("Note: Results are from one fixed 80/20 holdout; CV MAE is also reported.")

if __name__ == "__main__":
    main()
